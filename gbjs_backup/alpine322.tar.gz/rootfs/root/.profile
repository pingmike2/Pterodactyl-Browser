export HISTFILE=/dev/null
